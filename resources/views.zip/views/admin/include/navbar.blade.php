   @php
       $roles = ['Super Admin', 'Admin', 'Member'];
   @endphp
   <!-- Navbar -->
   <header class="navbar">
       <button class="toggle-btn" id="toggleBtn">
           <div class="hamburger">
               <span></span>
               <span></span>
               <span></span>
           </div>
       </button>

       <div class="search-bar">
           <input type="text" placeholder="Search here..." />
           <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
               stroke-width="2">
               <circle cx="11" cy="11" r="8"></circle>
               <path d="m21 21-4.35-4.35"></path>
           </svg>
       </div>

       <div class="navbar-actions">
           <button class="nav-icon">
               <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                   stroke-width="2">
                   <circle cx="12" cy="12" r="5"></circle>
                   <line x1="12" y1="1" x2="12" y2="3"></line>
                   <line x1="12" y1="21" x2="12" y2="23"></line>
                   <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                   <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                   <line x1="1" y1="12" x2="3" y2="12"></line>
                   <line x1="21" y1="12" x2="23" y2="12"></line>
                   <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                   <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
               </svg>
           </button>

           <button class="nav-icon">
               <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                   stroke-width="2">
                   <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                   <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
               </svg>
               <span class="notification-badge"></span>
           </button>

           <div class="dropdown" id="userDropdown">
               <div class="user-profile">
                   {{-- <img
                src="https://i.pravatar.cc/150?img=12"
                alt="User"
                class="user-avatar"
              /> --}}
                   <div
                       class="w-10 h-10 flex items-center justify-center rounded-full bg-[var(--primary-color)] text-white">
                       {{ strtoupper(substr(Auth::guard('admin')->user()->name, 0, 1)) }}
                   </div>

                   <div class="user-info">
                       <div class="user-name">{{ substr(Auth::guard('admin')->user()->email, 0, 12) . '...' }}</div>
                       <div class="user-role">{{ $roles[Auth::guard('admin')->user()->type] }}</div>
                   </div>
               </div>
               <div class="dropdown-menu">
                   <div class="dropdown-header">
                       <div class="user-name">{{ Auth::guard('admin')->user()->email }}</div>
                       <div class="user-role">{{ Auth::guard('admin')->user()->name }}</div>
                   </div>
                   <a href="#" class="dropdown-item">
                       <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                           stroke-width="2">
                           <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                           <circle cx="12" cy="7" r="4"></circle>
                       </svg>
                       Profile
                   </a>


                   <a href="#" class="dropdown-item">
                       <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                           stroke-width="2">
                           <circle cx="12" cy="12" r="3"></circle>
                           <path d="M12 1v6m0 6v6"></path>
                       </svg>
                       Account Settings
                   </a>


                   <form action="{{ route('admin.logout') }}" method="post" class="w-full">
                       @csrf
                       <button type="submit" class="dropdown-item logout w-full cursor-pointer">
                           <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                               stroke="currentColor" stroke-width="2">
                               <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                               <polyline points="16 17 21 12 16 7"></polyline>
                               <line x1="21" y1="12" x2="9" y2="12"></line>
                           </svg>
                           Logout
                       </button>
                   </form>
               </div>
           </div>
       </div>
   </header>
