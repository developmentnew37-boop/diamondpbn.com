@extends('admin.layout.layout')



@section('title', 'users')

@php
    $roles = ['Super Admin', 'Admin', 'Member'];

@endphp

@section('main-content')

    {{-- bread-crumbs --}}
    <div class="page-header">
        <div class="w-full flex flex-wrap items-center">
            <div class="w-1/2 flex flex-col gap-2 flex-wrap">
                <h2 class="page-title">Users</h2>
                <div class="breadcrumb">
                    <div class="breadcrumb-item">
                        <a href="{{ route('admin.dashboard') }}" class="breadcrumb-link">Dashboard</a>
                        <span>›</span>
                    </div>
                    <div class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Admin Users</a>
                    </div>
                </div>
            </div>
            <div class="w-1/2 flex flex-wrap justify-end items-center">
                <a href="{{ route('admin.user.create') }}" id="make__admin__user"
                    class="flex !p-2 !py-3 text-[16px] font-normal w-1/5 justify-center duration:300 bg-black hover:bg-[var(--primary-color)] text-white rounded ">
                    Add User
                </a>
            </div>
        </div>
    </div>




    <div class="w-full flex flex-wrap gap-8 justify-center  ">
        <div class="w-full flex flex-wrap gap-4 justify-center ">
            <div class=" w-full mx-auto content-card ">
                <div class="px-6 pt-6 flex flex-col gap-3 justify-between">
                    {{-- heading here --}}
                    <h2 class="text-xl bg-[var(--primary-color)] text-white !p-2 rounded font-semibold  capitalize w-fit">
                        Admin & Members Account <span class="material-symbols-outlined !text-sm">
                            arrow_cool_down
                        </span>
                    </h2>

                    {{-- table code here --}}

                    <div class="flex flex-wrap overflow-x-auto !mt-6">
                        <table class="w-full border border-gray-200 border-collapse text-sm whitespace-nowrap">
                            <thead>
                                <tr class="bg-[var(--sidebar-bg)] text-white  active-border-color ">
                                    @php
                                        $tHead = ['sno', 'Name', 'Email', 'Role', 'Created At', 'Action'];
                                    @endphp
                                    @foreach ($tHead as $t)
                                        <th
                                            class="border border-gray-50 font-sans !font-normal !px-3 !py-4 capitilize text-left">
                                            {{ $t }}
                                        </th>
                                    @endforeach
                                </tr>


                            </thead>
                            <tbody>



                                @foreach ($users as $index => $user)
                                    <tr class="hover:bg-gray-50">
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">{{ $index + 1 }}
                                        </td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $user->name }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $user->email }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $roles[$user->type] }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ now()->format('d-M-Y') }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            <div class="flex flex-wrap gap-2 !px-3">
                                                <a href="javascript:void(0)"
                                                    class="bg-green-600  flex items-center justify-center rounded-full w-8 h-8 duration-500 hover:bg-green-700">
                                                    <span class="material-symbols-outlined !text-[16px] text-white">
                                                        visibility
                                                    </span>
                                                </a>
                                                <a href="javascript:void(0)"
                                                    class="bg-yellow-500 flex items-center justify-center rounded-full w-8 h-8 duration-500 hover:bg-yellow-600">
                                                    <span class="material-symbols-outlined !text-[16px] text-white">
                                                        edit_square
                                                    </span>
                                                </a>
                                                @if ($user->type != '0')
                                                    <a href="javascript:void(0)"
                                                        class="bg-red-600 flex items-center justify-center rounded-full w-8 h-8 duration-500 hover:bg-yellow-600">
                                                        <span class="material-symbols-outlined !text-[16px] text-white">
                                                            delete
                                                        </span>
                                                    </a>
                                                @endif

                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="w-full flex flex-col">
                        @if ($paginate)
                            {{ $users->links() }}
                        @endif
                    </div>


                </div>


            </div>

        </div>

    </div>


@endsection
