<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Diamond Pbn</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />

    <link rel="stylesheet" href="{{ asset('build/assets/app-D5AzD2eA.css') }}">
    <script src="{{ asset('build/assets/app-Cwyqw0uf.js') }}"></script>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="{{ asset('js/script.js') }}" defer></script>
    <script src="{{ asset('js/dash-charts.js') }}" defer></script>
</head>

<body>
    <!-- Sidebar Overlay for Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    @include('admin.include.sidebar')

    <!-- Main Wrapper -->
    <div class="main-wrapper">
        <!-- Navbar -->
        @include('admin.include.navbar')

        <!-- Main Content -->
        <main class="main-content">
            {{-- bread-crumbs --}}
            <div class="page-header">
                <h1 class="page-title">Dashboards</h1>
                <div class="breadcrumb">
                    <div class="breadcrumb-item">
                        <a href="#" class="breadcrumb-link">Dashboard</a>
                    </div>

                </div>
            </div>

            <div class="content-card">
                <h2 class="card-title font-sans">PBN Analytics</h2>
                <h2 class="text-sm text-gray-700 font-sans">PBN general analytics</h2>
                <div class="w-full flex p-2 flex-wrap gap-2 !gap-y-6 justify-between !mt-4">
                    @php
                        $stats = [
                            [
                                'count' => 8,
                                'label' => 'No of Users',
                                'bg' => 'bg-green-200',
                                'stroke' => 'green',
                                'icon' => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>',
                            ],
                            [
                                'count' => 657,
                                'label' => 'No of Members',
                                'bg' => 'bg-gray-700',
                                'stroke' => '#e5e7eb',
                                'icon' => '
                                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                  <circle cx="9" cy="7" r="4"></circle>
                                  <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                  <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                               ',
                            ],
                            [
                                'count' => 4587,
                                'label' => 'No of Domains',
                                'bg' => 'bg-orange-100',
                                'stroke' => 'orange',
                                'icon' => '<circle cx="12" cy="12" r="10"></circle>
                        <line x1="2" y1="12" x2="22" y2="12"></line>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>',
                            ],
                            [
                                'count' => 8129,
                                'label' => 'No of Articles',
                                'bg' => 'bg-purple-100',
                                'stroke' => 'purple',
                                'icon' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>',
                            ],
                            [
                                'count' => 15611,
                                'label' => 'No of Sidebar Post',
                                'bg' => 'bg-red-200',
                                'stroke' => 'red',
                                'icon' => '<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                        <polyline points="13 2 13 9 20 9"></polyline>',
                            ],
                            [
                                'count' => 1457,
                                'label' => 'No of Sticky Post',
                                'bg' => 'bg-[#8cdcff]',
                                'stroke' => '#0094d4',
                                'icon' => '<line x1="12" y1="17" x2="12" y2="22"></line>
                        <path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"></path>',
                            ],
                            [
                                'count' => 899,
                                'label' => 'No of Schedule Post',
                                'bg' => 'bg-[#ffc7bd]',
                                'stroke' => '#ff6e54',
                                'icon' => '<circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>',
                            ],
                        ];
                    @endphp
                    @foreach ($stats as $stat)
                        <div
                            class="w-[13%] text-sm bg-gray-50 rounded-md flex flex-col  !p-4 items-center gap-2  border border-[#eee]">
                            <div
                                class="w-[50px] h-[50px] {{ $stat['bg'] }} rounded-full flex items-center justify-center">
                                <svg viewBox="0 0 24 24" width="24" height="24" fill="none"
                                    stroke="{{ $stat['stroke'] }}" stroke-width="2">
                                    {!! $stat['icon'] !!}
                                </svg>
                            </div>
                            <h2 class="font-sans font-bold text-3xl capitalize">{{ $stat['count'] }}</h2>
                            <h2 class="text-md text-gray-600 font-sans">{{ $stat['label'] }}</h2>
                        </div>
                    @endforeach

                </div>
            </div>
            {{-- graphics --}}
            <div class="w-full flex flex-wrap gap-4 justify-center overflow-hidden ">
                <div class="max-w-7xl w-[74%] mx-auto content-card ">
                    {{-- <div class="content-card"> --}}
                    <div class="px-6 pt-6 flex items-center justify-between">
                        <h2 class="text-lg font-semibold">PBN data analytics</h2>

                        <!-- legend (matches the screenshot vibe) -->
                        <div class="hidden sm:flex items-center gap-4 text-sm">
                            <span class="inline-flex items-center gap-2">
                                <span class="h-2.5 w-2.5 rounded-full bg-[#ff4a17]"></span> Pbn Post campaigns
                            </span>
                            <span class="inline-flex items-center gap-2">
                                <span class="h-2.5 w-2.5 rounded-full bg-slate-300"></span> Pbn Blogroll campaigns
                            </span>
                            <span class="inline-flex items-center gap-2">
                                <span class="h-2.5 w-2.5 rounded-full bg-slate-400"></span> Pbn sticky Post campaigns
                            </span>
                        </div>
                    </div>

                    <div class="p-2 sm:p-6 ">
                        <div id="pbncampaigns-data" class="h-[340px] w-full"></div>
                    </div>
                    {{-- </div> --}}
                </div>
                <div class="w-1/4 max-w-[600px] flex flex-col content-card">
                    <div class="flex items-center justify-between mb-4 w-full">
                        <h2 class="text-lg font-semibold">Articles Usage</h2>
                        <button
                            class="flex items-center gap-1 !px-3 !py-1.5 text-sm font-sans cursor-pointer bg-slate-100 rounded-lg font-medium hover:bg-slate-200 transition">
                            Monthly
                            <svg class="h-4 w-4 opacity-60" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.25 8.29a.75.75 0 01-.02-1.08z"
                                    clip-rule="evenodd" />
                            </svg>
                        </button>
                    </div>

                    <div id="articlesChart" class=""></div>
                    <div id="articlesPercent" class="text-4xl text-center font-bold mt-2 -translate-y-[100%]"
                        style="color: var(--primary-color)">0%</div>

                    <div class="mt-4 grid grid-cols-3 justify-center text-sm text-slate-600 w-full !mb-4">
                        <div class="flex flex-col gap-2 items-center">
                            <div class="font-medium text-slate-500">Total Articles</div>
                            <div id="TotalCount" class="text-base font-semibold">1000</div>
                        </div>
                        <div class="flex flex-col gap-2 items-center">
                            <div class="font-medium text-slate-600">Used</div>
                            <div id="usedCount" class="text-base font-semibold">0</div>
                        </div>
                        <div class="flex flex-col gap-2 items-center">
                            <div class="font-medium text-slate-500">Remaining</div>
                            <div id="remainingCount" class="text-base font-semibold">0</div>
                        </div>
                    </div>

                    <div class="!mt-6 rounded bg-indigo-50 !px-4 !py-3 text-sm text-slate-700">
                        <span id="usageMsg"></span>
                    </div>
                </div>
            </div>

            <div class="w-full flex flex-wrap gap-4 justify-center overflow-hidden ">
                <div class="max-w-7xl w-[74%] mx-auto content-card ">
                    {{-- <div class="content-card"> --}}
                    <div class="px-6 pt-6 flex justify-between">
                        <h2 class="text-lg font-semibold">PBN Orders Campaigns Data</h2>



                    </div>
                    <div class="flex flex-wrap gap-2 items-center  !mt-5">
                        @php
                            $tab_btn_arr = [
                                [
                                    'label' => 'PBN Post Campaigns',
                                    'bg_class' => 'active-bg',
                                    'link' => '?campaigns=post',
                                    'id' => '#',
                                ],
                                [
                                    'label' => 'PBN Sidebar Post Campaigns',
                                    'bg_class' => 'bg-black',
                                    'link' => '?campaigns=sidebar',
                                    'id' => '#',
                                ],
                                [
                                    'label' => ' PBN Dripfeed Campaigns',
                                    'bg_class' => 'bg-black',
                                    'link' => '?campaigns=dripfeed',
                                    'id' => '#',
                                ],
                                [
                                    'label' => 'PBN Sticky Post Campaigns',
                                    'bg_class' => 'bg-black',
                                    'link' => '?campaigns=sticky',
                                    'id' => '#',
                                ],
                            ];
                        @endphp

                        @foreach ($tab_btn_arr as $indx => $item)
                            <a href="{{ $item['link'] }}" id="{{ $item['id'] }}"
                                class="{{ $item['bg_class'] }} !p-3 rounded text-center  text-sm font-sans text-white cursor-pointer duration-300 hover:bg-[var(--primary-color)]">
                                {{ $item['label'] }}
                            </a>
                        @endforeach
                    </div>
                    <div class="flex flex-wrap overflow-x-auto !mt-6">
                        <table class="w-full border border-gray-200 border-collapse text-sm whitespace-nowrap">
                            <thead>
                                <tr class="bg-black text-white active-border-color ">
                                    @php
                                        $tHead = [
                                            'sno',
                                            'Campaign',
                                            'Domains',
                                            'Quantity',
                                            'Links',
                                            'Keywords',
                                            'Date',
                                            'Action',
                                        ];
                                    @endphp
                                    @foreach ($tHead as $t)
                                        <th
                                            class="border border-gray-200 font-sans !font-normal !px-2 !py-3 capitilize text-left">
                                            {{ $t }}
                                        </th>
                                    @endforeach
                                </tr>


                            </thead>
                            <tbody>

                                @php
                                    // ✅ Generate 10 dummy campaign rows
                                    $campaigns = [];
                                    for ($i = 1; $i <= 10; $i++) {
                                        $campaigns[] = [
                                            'campaign' => 'pbn-' . rand(100000000000, 999999999999),
                                            'domain' => 'domain' . $i . '.id',
                                            'quantity' => rand(20, 100),
                                            'links' => rand(10, 50),
                                            'keywords' => rand(1, 5),
                                            'date' => now()
                                                ->subDays($i * 2)
                                                ->format('d-m-Y'),
                                        ];
                                    }
                                @endphp

                                @foreach ($campaigns as $index => $campaign)
                                    <tr class="hover:bg-gray-50">
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">{{ $index + 1 }}
                                        </td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $campaign['campaign'] }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $campaign['domain'] }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $campaign['quantity'] }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $campaign['links'] }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $campaign['keywords'] }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            {{ $campaign['date'] }}</td>
                                        <td class="border border-gray-200 font-sans !px-2 !py-2">
                                            <div class="flex flex-wrap gap-2 justify-center">
                                                <a href="javascript:void(0)"
                                                    class="bg-black flex items-center justify-center rounded-full w-8 h-8 duration-500 hover:bg-gray-700 relative overflow ">
                                                    <span class="material-symbols-outlined !text-[16px] text-white">
                                                        visibility
                                                    </span>
                                                </a>
                                                <a href="javascript:void(0)"
                                                    class="bg-yellow-500 flex items-center justify-center rounded-full w-8 h-8 duration-500 hover:bg-yellow-600">
                                                    <span class="material-symbols-outlined !text-[16px] text-white">
                                                        edit_square
                                                    </span>
                                                </a>
                                                <a href="javascript:void(0)"
                                                    class="bg-green-600  flex items-center justify-center rounded-full w-8 h-8 duration-500 hover:bg-green-700">
                                                    <span class="material-symbols-outlined !text-[16px] text-white">
                                                        download
                                                    </span>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    {{-- </div> --}}
                </div>
                <div class="w-1/4 max-w-[600px] flex flex-col content-card">
                    <div class="flex flex-col gap-5 mb-4 w-full">
                        <h2 class="text-lg font-semibold">Domains Categories</h2>
                        <div class="flex  flex-wrap overflow-x-auto w-full">
                            <table class="w-full border border-gray-200 border-collapse text-sm whitespace-nowrap">
                                <thead>
                                    <tr class="active-bg text-white active-border-color ">
                                        @php
                                            $tHead2 = ['sno', 'Domains', 'Quantity', 'Action'];
                                            $domains_data = [
                                                [
                                                    'domain' => 'General Domains',
                                                    'quantity' => '2780',
                                                ],
                                                [
                                                    'domain' => 'Premium Domains',
                                                    'quantity' => '112',
                                                ],
                                                [
                                                    'domain' => 'ID Domains',
                                                    'quantity' => '518',
                                                ],
                                                [
                                                    'domain' => 'Uk Domains',
                                                    'quantity' => '518',
                                                ],
                                                [
                                                    'domain' => 'De Domains',
                                                    'quantity' => '74',
                                                ],
                                                [
                                                    'domain' => 'US Domains',
                                                    'quantity' => '90',
                                                ],
                                                [
                                                    'domain' => 'ID Domains',
                                                    'quantity' => '518',
                                                ],
                                                [
                                                    'domain' => 'Uk Domains',
                                                    'quantity' => '518',
                                                ],
                                                [
                                                    'domain' => 'De Domains',
                                                    'quantity' => '74',
                                                ],
                                                [
                                                    'domain' => 'US Domains',
                                                    'quantity' => '90',
                                                ],
                                            ];
                                        @endphp
                                        @foreach ($tHead2 as $t)
                                            <th
                                                class="border border-gray-200 font-sans !font-normal !px-2 !py-3 capitilize text-left">
                                                {{ $t }}
                                            </th>
                                        @endforeach
                                    </tr>


                                </thead>
                                <tbody>

                                    @foreach ($domains_data as $index => $domain)
                                        <tr class="hover:bg-gray-50">
                                            <td class="border border-gray-200 font-sans !px-2 !py-3">
                                                {{ $index + 1 }}
                                            </td>
                                            <td class="border border-gray-200 font-sans !px-2 !py-3">
                                                {{ $domain['domain'] }}</td>
                                            <td class="border border-gray-200 font-sans !px-2 !py-3">
                                                {{ $domain['quantity'] }}</td>
                                            <td class="border border-gray-200 font-sans !px-2 !py-2">
                                                <div class="flex flex-wrap gap-2 justify-center">
                                                    <a href="javascript:void(0)"
                                                        class="bg-black flex items-center justify-center rounded-full w-8 h-8 duration-500 hover:bg-gray-700 relative overflow ">
                                                        <span
                                                            class="material-symbols-outlined !text-[16px] text-white">
                                                            visibility
                                                        </span>
                                                    </a>

                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach





                                </tbody>

                            </table>
                        </div>
                        <div class="w-full flex justify-end">
                            <a href="#"
                                class="bg-black !p-3 rounded text-center  text-sm font-sans text-white cursor-pointer duration-300 ">view
                                more</a>
                        </div>
                    </div>

                </div>
            </div>

        </main>

        <!-- Footer -->
        {{-- @include('admin.include.footer') --}}

    </div>

</body>

</html>
